package org.zerock.task;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j;

@Log4j
@Component
public class Page598_FileCheckTask {

	// Page598 소스 코딩
	// FileCheckTask의 checkFiles()는 매분 0초마다 한 번씩 동작하게 설정했습니다.
	@Scheduled(cron = "0 * * * * *")
	public void checkFiles() {
		log.warn("File Check Task run.......");
		log.warn("=====================================");
	}
}

// 실행 확인 = FileCheckTask에서 마우스 우클릭 - Run As - Run On Server로
// 서버를 실행해 두고 1분에 한 번씩 로그가 기록되는지를 확인합니다.
//STS 콘솔 확인
//~~ 위에 생략 ~~
//WARN : org.zerock.task.FileCheckTask - File Check Task run. . . . . . . . . . . . . .
//WARN : org.zerock.task.FileCheckTask - ==============================================
