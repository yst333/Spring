package org.zerock.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyPageDTO;
import org.zerock.domain.ReplyVO;
import org.zerock.service.ReplyService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RequestMapping("/replies/")
@RestController
@Log4j
@AllArgsConstructor
public class ReplyController {
	
	private ReplyService service;
	
	// create() 메서드는 @PostMapping으로 POST 방식으로만 동작하도록 설계하고,
	// consumes와 produces를 이용해서 JSON 방식의 데이터만 처리하도록 하고,
	// 문자열을 반환하도록 설계합니다. create()의 파라미터는 @RequestBody를 적용해서
	// JSON 데이터를 ReplyVO 타입으로 변환하도록 지정합니다.
	// create() 메서드는 내부적으로 ReplyServiceImpl을 호출해서 register()를 호출하고,
	// 댓글이 추가된 숫자를 확인해서 브라우저에서 '200 OK' 혹은 '500 Internal Server Error'를
	// 반환하도록 처리 합니다.
	// Page729 스프링 시큐리티 : 아래 1줄 소스 추가 코딩
              // ReplyController에서는 댓글 등록이 로그인한 사용자인지를 확인하도록 합니다.
	// (웹페이지에서 새로운 댓글 추가하려고 할때 댓글 작성자(replyer)는 고정된 형태로 보이게 되고,
	//  전송 시 CSRF 토큰이 같이 전송 처리 됩니다)
	@PreAuthorize("isAuthenticated()")
	@PostMapping(value = "/new",
			consumes = "application/json",
			produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> create(@RequestBody ReplyVO vo){
		log.info("ReplyVo : " + vo);
		
		int insertCount = service.register(vo);
		
		log.info("Reply INSERT COUNT : " + insertCount);
		
		// return문은 삼항 연산자 처리
		return insertCount == 1 ? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);				
	}
	
	// ReplyController의 getList()는 Criteria를 이용해서 파라미터를 수집하는데,
	// '/{bno}/{page}'의 'page'값은 Criteria를 생성해서 직접 처리해야 합니다.
	// 게시물의 번호는 @PathVariable을 이용해서 파라미터(매개변수)로 처리하고
	// YARC 브라우저에서 테스트해 봅니다.
	// Page435 ReplyController의 일부 수정 코딩 할 때 아래 소스는 주석 처리 해줌.
//	@GetMapping(value = "/pages/{bno}/{page}",
//			produces = {MediaType.APPLICATION_XML_VALUE,
//					MediaType.APPLICATION_JSON_UTF8_VALUE})
//	public ResponseEntity<List<ReplyVO>> getList(
//			@PathVariable("page") int page,
//			@PathVariable("bno") Long bno){
//		log.info("getList...........");
//		Criteria cri = new Criteria(page, 10);
//		return new ResponseEntity<>(service.getList(cri, bno), HttpStatus.OK);		
//	}
	
	// Page435 ReplyController의 일부 수정 코딩 처리 해줌.
	@GetMapping(value = "/pages/{bno}/{page}",
			produces = {MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_UTF8_VALUE})
	public ResponseEntity<ReplyPageDTO> getList(
			@PathVariable("page") int page,
			@PathVariable("bno") Long bno){
		
		Criteria cri = new Criteria(page, 10);
		log.info("get Reply List bno : " + bno);
		log.info("cri : " + cri);
		
		return new ResponseEntity<>(service.getListPage(cri, bno), HttpStatus.OK);		
	}
	
	@GetMapping(value = "/{rno}",
			produces = {MediaType.APPLICATION_XML_VALUE,
						MediaType.APPLICATION_JSON_UTF8_VALUE})
	public ResponseEntity<ReplyVO> get(
			@PathVariable("rno") Long rno){
			log.info("get : " + rno);
			return new ResponseEntity<>(service.get(rno), HttpStatus.OK);
	}

	// 댓글 삭제를 위한 remove() 메서드 선언	
	// Page732 ReplyController에서 스프링 시큐리티를 적용해 줍니다.
	// 그리고, JSON으로 전송되는 데이터를 처리하도록 아래와 같이 수정 코딩해 줍니다.
	@PreAuthorize("principal.username == #vo.replyer")
	@DeleteMapping(value = "/delete/{rno}", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> remove(@RequestBody ReplyVO vo, @PathVariable("rno") Long rno){
		log.info("remove : " + rno);
		
		log.info("replyer 댓글 작성자 = " + vo.getReplyer());
		
		return service.remove(rno) == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
//	@PostMapping(value = "/delete/{rno}", produces = {MediaType.TEXT_PLAIN_VALUE})
//	public ResponseEntity<String> remove(@PathVariable("rno") Long rno){
//		log.info("remove : " + rno);
//		
//		return service.remove(rno) == 1
//				? new ResponseEntity<>("success", HttpStatus.OK) : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//	}
	
	// 댓글 수정은 'PUT' 방식이나 'PATCH' 방식을 이용하도록 처리합니다.
	// 실제 수정되는 데이터는 JSON 데이터 형식이므로 @RequestBody를 이용해서 처리합니다.
	// @RequestBody로 처리되는 데이터는 일반 파라미터(매개변수)나 @PathVariable 파라미터를
	// 처리할 수 없기 때문에 직접 처리해 주는 부분을 주의해야 합니다.
	// Page734 스프링 시큐리티 적용 : 아래 1줄 소스 코딩해 줌.
	@PreAuthorize("principal.username == #vo.replyer")
	@RequestMapping(method = {RequestMethod.PUT, RequestMethod.PATCH},
			value = "/modify/{rno}",
			consumes = "application/json",
			produces = {MediaType.TEXT_PLAIN_VALUE})			
	public ResponseEntity<String> modify(
			@RequestBody ReplyVO vo, @PathVariable("rno") Long rno){
		vo.setRno(rno);
		log.info("rno : " + rno);
		log.info("modify : " + vo);
		
		return service.modify(vo) == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);		
	}	
}










