package org.zerock.domain;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class BoardVO {

	private Long bno;      // 게시글 번호 필드 정의
	private String title;  // 게시글 제목 필드 정의
	private String content; // 게시글 내용 필드 정의
	private String writer;  // 게시글 작성자 필드 정의
	private Date regdate;   // 게시글 등록 일시 정보 필드 정의
	private Date updateDate; // 게시글 갱신 일시 정보 필드 정의
	
	// Page481 BoardVO 클래스에 replyCnt(댓글 갯수) 필드 추가
	private int replyCnt;
	
	// Page552 BoardVO 클래스에 attachList(첨부파일 정보) 필드 추가
	private List<BoardAttachVO> attachList;
	
}
