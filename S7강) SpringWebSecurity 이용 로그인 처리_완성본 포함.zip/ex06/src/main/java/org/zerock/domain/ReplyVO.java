package org.zerock.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ReplyVO {

	private Long rno;  // 댓글 번호 필드 정의
	private Long bno;  // (참조 되는) 게시글 번호 필드 정의
	
	private String reply; // 댓글 내용 필드 정의
	private String replyer; // 댓글 등록한 사람 필드 정의
	private Date replyDate;  // 댓글 등록 일시 정보 필드 정의
	private Date updateDate;  // 댓글 등록 수정 일시 정보 필드 정의
}
