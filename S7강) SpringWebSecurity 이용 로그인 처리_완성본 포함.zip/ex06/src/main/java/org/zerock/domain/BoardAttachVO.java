package org.zerock.domain;

import lombok.Data;

@Data
public class BoardAttachVO {

	private String uuid;       // 첨부파일 보관 시 UUID 포함된 이름을 PK로 하는 uuid 필드 정의
	private String uploadPath; // 실제 파일이 업로드된 경로를 의미하는 uploadPath 필드 정의
	private String fileName;   // 파일 이름을 의미하는 fileName 필드 정의
	private boolean fileType;  // 이미지 파일 여부를 판단할 수 있는 fileType 필드 정의
	
	private Long bno; // 해당 게시물 번호를 저장하는 bno 필드 정의
	
}
