package org.zerock.controller;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Test {

	private String name;
	private int age;
	
}



