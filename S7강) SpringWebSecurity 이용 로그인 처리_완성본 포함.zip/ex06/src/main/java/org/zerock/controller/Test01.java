package org.zerock.controller;

public class Test01 {

	public static void main(String[] args) {
		
		// 1페이지의 경우 : Math.ceil(0.1) * 10 = 1.0 * 10 = 10
		System.out.println(Math.ceil(0.1));  // 1.0
		
		// 10페이지의 경우 : Math.ceil(1) * 10 = 1.0 * 10 = 10
		System.out.println(Math.ceil(1));  // 1.0
		
		// 11페이지의 경우 : Math.ceil(1.1) * 10 = 2.0 * 10 = 20
		System.out.println(Math.ceil(1.1));  // 2.0

	}

}
