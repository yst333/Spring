package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.BoardAttachVO;

// BoardAttachMapper 클래스의 경우, 첨부파일의 수정이라는 개념이 존재하지 않기 때문에,
// insert()와 delete() 작업만을 처리합니다.
// 특정 게시물의 번호로 첨부파일을 찾는 작업이 필요하므로 findByBno() 메서드를 정의합니다.
public interface BoardAttachMapper {

	public void insert(BoardAttachVO vo);
	
	public void delete(String uuid);
	
	public List<BoardAttachVO> findByBno(Long bno);
	
	// Page578 첨부파일 삭제 처리를 위한 deleteAll() 메서드 선언
	public void deleteAll(Long bno);
	
	// Page600 BoardAttachMapper에 첨부파일 목록을 가져오는 getOldFiles() 메서드를 추가해 줍니다.
	public List<BoardAttachVO> getOldFiles();
}





