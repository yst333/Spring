package org.zerock.service;


public interface SampleTxService {

	public void addData(String value);
	
	public void addTest(String value);
}
