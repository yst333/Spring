package org.zerock.service;

public interface SampleService {
	
	// 문자열 타입 str1과 문자열 타입 str2를 매개변수로 갖는 추상 메서드 doAdd() 정의
	public Integer doAdd(String str1, String str2) throws Exception;
}
