package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.mapper.BoardAttachMapper;
import org.zerock.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class BoardServiceImpl implements BoardService {

	// 아래와 같이 @Autowired를 직접 설정해 줄 수도 있고, Setter를 이용해서 처리할 수도 있지만
	// @Setter(onMethod_ = @Autowired)
	// 스프링 4.3부터는 단일 파라미터를 받는 생성자의 경우에는 필요한 파라미터를 자동으로 주입할 수 있습니다.
	// 위에서 @AllArgsConstructor는 모든 파라미터를 이용하는 생성자를 만들기 때문에
	// 실제 코드는 BoardMapper를 주입받는 생성자가 만들어지게 됩니다.
	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;
	
	// Page566 25.3.1 BoardServiceImple 처리
	// 2개의 Mapper를 주입 받아야 하기 때문에
	// 자동주입 대신에 Setter 메서드를 이용하도록 수정해 줍니다.
	// 즉, 위에 다음과 같이 @Setter 메서드 처리해 주고,
	// @Setter(onMethod_ = @Autowired)
	// private BoardMapper mapper;
	// 아래에 다음과 같이 @Setter 메서드를 처리해 줍니다.
	// @Setter(onMethod_ = @Autowired)
	// private BoardAttachMapper attachMapper;
	@Setter(onMethod_ = @Autowired)
	private BoardAttachMapper attachMapper;

	// Page567 게시물의 등록 작업은 tbl_board 테이블과 tbl_attach 테이블 양쪽 모두
	// insert가 진행되어야 하기 때문에 트랜잭션 처리(@Transactional)가 필요합니다.
	// BoardServiceImpl의 register()는 트랜잭션 하에서 tbl_board에
	// 먼저 게시물을 등록하고, 각 첨부파일은 생성된 게시물 번호(bno)를 세팅한 후
	// tbl_attach 테이블에 데이터를 추가합니다.	
	@Transactional
	@Override
	public void register(BoardVO board) {
		
		log.info("register....." + board);
		
		mapper.insertSelectKey(board);
		
		// Page567 아래 4줄 소스 추가 코딩
		if(board.getAttachList() == null || board.getAttachList().size() <= 0) {
			return;
		}		
		board.getAttachList().forEach(attach -> {
			attach.setBno(board.getBno());
			attachMapper.insert(attach);			
		});		
	}

	@Override
	public BoardVO get(Long bno) {
		log.info("get......." + bno);
		return mapper.read(bno);
	}

		// Page591 BoardService에서 게시물의 수정은 우선 기존의 첨부파일 관련 데이터를
		// 삭제한 후에 다시 첨부파일 데이터를 추가하는 방식으로 동작합니다. 그러기 위해
		// BoardService(Impl) 수정 코딩을 합니다.
		@Transactional
		@Override
		public boolean modify(BoardVO board) {
			log.info("modify... 게시글을 수정 처리 합니다!" + board);
			
			// Page591 아래 소스 코딩 추가 시작
			// 참고로, 첨부파일은 수정이라기 보다는 삭제 후에 다시 추가한다는 개념이므로
			// 게시물의 수정 전과 수정 후의 데이터베이스 tbl_board, tbl_attach 테이블의
			// 변경 사항도 확인해 주시기 바랍니다.
			attachMapper.deleteAll(board.getBno());
			boolean modifyResult = mapper.update(board) == 1;
			if(modifyResult && board.getAttachList() != null && board.getAttachList().size() > 0) {
				board.getAttachList().forEach(attach -> {
					attach.setBno(board.getBno());
					attachMapper.insert(attach);
				});
			}
			return modifyResult; // 왼쪽 소스 코딩까지가 Page591 소스 코딩 추가 끝
			
			
			// 정상적으로 수정이 이루어지면 1이라는 값이 반환되기 때문에
			// '==' 연산자를 이용해서 true/false를 처리할 수 있습니다.			
			// Page591 소스 코딩할 때 아래 1줄 소스 주석 처리
			// return mapper.update(board) == 1;
		}

	// Page579 BoardServiceImple 클래스의 remove() 메서드는 첨부파일 삭제와 실제 게시물의 삭제가
	// 같이 처리 되도록 트랜잭션 하에서 BoardAttachMapper의 deleteAll() 메서드를 호출하도록 수정 코딩합니다.
	@Transactional
	@Override
	public boolean remove(Long bno) {
		log.info("remove........" + bno);
		// 정상적으로 삭제 처리가 이루어지면 1이라는 값이 반환되기 때문에 '==' 연산자를 이용해서
		// true/false를 처리할 수 있습니다.	
		
		// Page579 아래 1줄 소스 코딩 추가해 줌
		attachMapper.deleteAll(bno);
		
		return mapper.delete(bno) == 1;
	}

//	@Override
//	public List<BoardVO> getList() {
//		
//		log.info("getList........");
//		
//		return mapper.getList();
//	}
	
	// Page299 getList() 메서드에 Criteria 타입의 cri 매개변수 정의
	@Override
	public List<BoardVO> getList(Criteria cri) {
		
		log.info("get List with criteria : " + cri);
		
		return mapper.getListWithPaging(cri);
	}

	@Override
	public int getTotal(Criteria cri) {
		
		log.info("get total count");
		return mapper.getTotalCount(cri);
	}

	// Page569 BoardServiceImpl은 이미 BoardAttachMapper를 주입하도록 설계한 상태이므로,
	// BoardAttachMapper 인터페이스의 findByBno()를 호출하고 반환하도록 코딩해 줍니다.
	@Override
	public List<BoardAttachVO> getAttachList(Long bno) {
		log.info("get Attach list by bno" + bno);
		return attachMapper.findByBno(bno);
	}
	
}



