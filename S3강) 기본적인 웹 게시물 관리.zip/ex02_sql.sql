drop table tbl_board cascade CONSTRAINTS;

drop SEQUENCE seq_board;
-- create sequence seq_board;

-- Sequence ������ 2���� �߰��� ���
create sequence seq_board
increment by 1
start with 0
maxvalue 9999999
minvalue 0;

create table tbl_board (
bno number(10, 0),
title varchar2(200) not null,
content varchar2(2000) not null,
writer varchar2(50) not null,
regdate date default sysdate,
updatedate date default sysdate
);

alter table tbl_board add constraint pk_board primary key (bno); 

-- ���� ������ 5�� ����
insert into tbl_board (bno, title, content, writer)
values (seq_board.nextval, '�׽�Ʈ ����', '�׽�Ʈ ����', 'user00');

select * from tbl_board;

commit;

select * from tbl_board;

-- Page 270
select * from tbl_board order by bno desc;

-- Page 271
insert into tbl_board (bno, title, content, writer)
(select seq_board.nextval, title, content, writer from tbl_board);

-- Page 272
commit;

-- Page 272
select count(*) from tbl_board;

-- Page 272
select * from tbl_board order by bno + 1 desc;

-- Page 273
select * from tbl_board order by bno desc;
